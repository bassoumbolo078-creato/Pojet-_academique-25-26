<?php
include_once "models/model.produit.php";
include_once "models/model.categorie.php";
include_once "models/model.users.php";
function getAllproducts():array{
    $produits= selectAllproduit();
    if (count($produits)==0){
        return [];
    }
    return getProduitsWithStock($produits);
}
function getProductsByCategorie(string $categorie):array{
    $produits= selectProduitByCategorie($categorie);
    if (count($produits)==0){
        return [];
    }
    return getProduitsWithStock($produits);
}
function getProduitsWithStock(array $produits):array{
    $produitsWithMntStock=[];
    foreach($produits as $produit){
        $produit["mntStock"]=$produit["prix"] * $produit["qtite"];
        $produitsWithMntStock[]=$produit;
    }
   return $produitsWithMntStock;
   
}
function addProduit(array $produit):void{
    insertProduit($produit);
}
function countProducts():int{
    $produits= selectAllproduit();
    return count($produits);
}

function getAllCategories():array{
    return selectAllCategorie();
}
function addCategorie(array $categorie):bool{
    $result=selectCategorieByLibelle($categorie["libelle"]);
    if ($result==null) {
        insertCategorie($categorie);
        return true;
    }
    
    return false;
    
}
function getMaxIdCategorie():int{
    $categories= selectAllCategorie();
    return getMaxId($categories,"code");
   
} 
function getMaxId(array $datas , string $key="id"):int{
     $maxId=0;
    foreach($datas as $data){
        if ($data[$key]>$maxId){
            $maxId=$data[$key];
        }
    }
    return $maxId;
}
function getMaxIdProduit():int{
    $produits= selectAllproduit();
    return getMaxId($produits);
} 
function getUserByLoginAndPassword(string $login,string $password):?array{
    return selectUserByLoginByPassword($login,$password);
}
