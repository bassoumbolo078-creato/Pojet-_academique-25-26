<?php
include_once dirname(__DIR__)."/fichier.php";
/*
selectAllproduit():array
slectProduitByCategorie(string $categorie):array
insertProduit(array $produit):void
updateProduit(string $id,array $produit):void
deleteProduit(string $id):void
*/ 
function selectAllproduit():array{
    $bd=readJson();
    if (count($bd)>0){
        return $bd["produits"];
    }
    return [];
}
function selectProduitByCategorie(string $categorie):array{
    $bd=readJson();
    $produitsByCategorie=[];
    if (count($bd)>0){
        foreach($bd["produits"] as $produit){
            if ($produit["categorie"]==$categorie){
                $produitsByCategorie[]=$produit;
            }
        }
        return $produitsByCategorie;
    }
    return [];
}
function insertProduit(array $produit):void{
    writeJson("produits",$produit);
}