<?php

include_once dirname(__DIR__)."/fichier.php";
define("USERS","users");
function selectUserByLoginByPassword(string $login,string $password):?array{
    $users=readJson()[USERS];
    foreach ($users as $user) {
        if($user["login"]==$login && $user["password"]==$password){
            return $user;

        }
        
    }
    return null;

}