<?php
include_once dirname(__DIR__)."/fichier.php";
define("CATEGORIES","categories");
function selectAllCategorie():array{
    $bd=readJson();
    if (count($bd)>0){
        return $bd[CATEGORIES];
    }
    return [];
}
function insertCategorie( array $categorie):void{
    writeJson(CATEGORIES,$categorie);
}
function selectCategorieByLibelle(string $libelle):?array{
 $categories=selectAllCategorie();
 foreach ($categories as $categorie) {
    if ($categorie["libelle"]==$libelle) {
        return $categorie;
    }
 }
 return null;
}