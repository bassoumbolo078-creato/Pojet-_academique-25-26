<?php
$produits=getAllproducts();
$categories=getAllCategories();
switch ($_REQUEST["btn-action"] ?? ""){
    case 'btn-add-product':
        $maxId=getMaxIdProduit();
        $produit=[
            "id"=>++$maxId,
            "libelle"=>$_REQUEST["libelle"],
            "categorie"=>$_REQUEST["categorie"],
            "prix"=>floatval($_REQUEST["prix"]),
            "qtite"=>intval($_REQUEST["qtite"])
        ];
        addProduit($produit);
        # code...
        break;
    case 'btn-filter':
        
        if (isset($_REQUEST["categorie"]) && $_REQUEST["categorie"]!="all"){
             $categorie=$_GET["categorie"];
             $produits=getProductsByCategorie($categorie);
             }
        break;
    default:
        # code...
        break;
}

?>
<div class="contenaire">
        <div class="formulaire">
            <form action="" method="post">
                <h2>Ajouter un produit</h2>
                <div class="form-control">
                <label>Libelle :</label>
                <input type="text" name="libelle" >
                </div>
                <div class="form-control">
                    <label>Prix :</label>
                    <input type="number" name="prix" >
                </div>
                <div class="form-control">
                    <label>Quantite :</label>
                    <input type="number" name="qtite" >
                </div>
            <div class="form-control">
                <label for="">Categorie</label>
                  <select name="categorie" >
                    <?php foreach($categories as $categorie): ?>
                        <option value="<?php echo $categorie["libelle"] ?>"><?php echo $categorie["libelle"] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="btn-save-produit">
                <button type="reset">Annuler</button>
                <button type="submit" name="btn-action" value="btn-add-product">Ajouter</button>
            </div>
                
                
            </form>
        </div>
        <div class="liste">
           <?php if (count($produits)==0):?>
                <p>Aucun produit disponible.</p>
            <?php else : ?>
            <div class="filtre">
                <form action="" method="get">
                    <label for="">Categorie</label>
                    <select name="categorie" id="categorie">
                        <option value="all">Tous</option>
                        <?php foreach($categories as $categorie): ?>
                        <option value="<?php echo $categorie["libelle"] ?>"><?php echo $categorie["libelle"] ?></option>
                    <?php endforeach; ?>
                    </select>
                    <button type="submit" name="btn-action" value="btn-filter">OK</button>
                </form>
            </div>
            <div class="produits-table">
                <h2>Liste des produits</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Libelle</th>
                            <th>Categorie</th>
                            <th>Prix</th>
                            <th>Quantite</th>
                            <th>Montant Stock</th>
                        </tr>
                    </thead>
                    <tbody>
                     <?php foreach($produits as $produit): ?>
                     
                    <tr>
                        <td><?php echo $produit["id"]?></td>
                        <td><?php echo $produit["libelle"]?></td>
                        <td><?php echo $produit["categorie"]?></td>
                        <td><?php echo $produit["prix"]?></td>
                        <td><?php echo $produit["qtite"]?></td>
                        <td><?php echo $produit["mntStock"]?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>

        </div>
</div>