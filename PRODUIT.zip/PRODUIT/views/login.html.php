<?php

?>
<div class="contenaire">
            <div class="formulaire">
            <form action="" method="post">
                <h2>Formulaire de Connexion</h2>
                <div class="form-control">
                <label>Login :</label>
                <input type="text" name="login" >
                <span class="text-error"><?php echo $errors["login"] ?? "" ?></span>
                </div>
                <div class="form-control">
                    <label>Password :</label>
                    <input type="text" name="password" >
                    <span class="text-error"><?php echo $errors["password"] ?? "" ?></span>
                </div>

                
            <div class="btn-save-produit">
                <button type="reset">Annuler</button>
                <button type="submit" name="btn-action" value="btn-login">Connexion</button>
            </div>
            </form>
        </div>
</div>  
