<?php
$categories=getAllCategories();
$errors=[];
switch ($_REQUEST["btn-action"] ?? ""){
    case 'btn-add-categorie':
        $maxId=getMaxIdCategorie();
        if (!empty($_REQUEST["libelle"])) {
            $categorie=[
            "code"=>++$maxId,
            "libelle"=>$_REQUEST["libelle"]
            ];
            $result=addCategorie($categorie);
            if ($result==false) {
                 $errors["libelle"]="Le libelle existe deja";
            }
        }else {
            $errors["libelle"]="Le champ libelle est obligatoire";
        }
        
        # code...
        break;
    default:
        # code...
        break;
}

?>
<div class="contenaire">
        <div class="formulaire">
            <form action="" method="post">
                <h2>Ajouter une categorie</h2>
                <div class="form-control">
                <label>Libelle :</label>
                <input type="text" name="libelle">
                <span class="text-error"><?php echo $errors["libelle"] ?? "" ?></span>
                </div>
                
            <div class="btn-save-produit">
                <button type="reset">Annuler</button>
                <button type="submit" name="btn-action" value="btn-add-categorie">Ajouter</button>
            </div>
                
                
            </form>
        </div>
        <div class="liste">
           <?php if (count($categories)==0):?>
                <p>Aucune categorie disponible.</p>
            <?php else : ?>
            <div class="produits-table">
                <h2>Liste des categories</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Libelle</th>
                        </tr>
                    </thead>
                    <tbody>
                     <?php foreach($categories as $categorie): ?>
                     
                    <tr>
                        <td><?php echo $categorie["code"]?></td>
                        <td><?php echo $categorie["libelle"]?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>

        </div>
</div>