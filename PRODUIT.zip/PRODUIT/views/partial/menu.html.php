 <h1>Gestion des produits</h1>
        <nav>
            <ul>
                <li><a href="<?php echo WEBROOT?>/?page=produit" >Produits</a></li>
                <li><a href="<?php echo WEBROOT?>/?page=categorie">Categories</a></li>
            </ul>
        </nav>