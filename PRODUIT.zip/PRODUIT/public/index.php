<?php
define("WEBROOT","http://localhost:8080");
$isconnected=false;
// if ($isconnected==false) {
//     //Redirige vers la page de connexion
//     header("location:".dirname(__DIR__)."/views/login.html.php");
// }
// $dataRequest=[];
// if ($_SERVER["REQUEST_METHOD"]=="POST"){
//     $dataRequest=$_POST;
// }else if ($_SERVER["REQUEST_METHOD"]=="GET"){
//    $dataRequest=$_GET;
// }
include_once dirname(__DIR__)."/services.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produits</title>
    <link rel="stylesheet" href="<?php echo WEBROOT?>/style.css">
</head>
<style>
   .text-error{
    padding: 5px;
    margin:3px;
    color:red;

   }
</style>
<body>
       
        <?php
        if ($isconnected) {
            // include_once dirname(__DIR__)."/views/partial/menu.html.php";
            # code...
        }
    
        $choix=$_REQUEST["page"] ?? "login";

        switch ($choix) {
            case 'produit':
                include_once dirname(__DIR__)."/views/produit.html.php";
                # code...
                break;
            case 'categorie':
                include_once dirname(__DIR__)."/views/categorie.html.php";
                # code...
                break;
            case 'login':
                $errors=[];
                switch ($_REQUEST["btn-action"] ?? ""){
    case 'btn-login':
        
        if (empty($_REQUEST["login"])) {
           $errors["login"]="Le champ login est obligatoire";
        }
        if (empty($_REQUEST["password"])) {
           $errors["password"]="Le champ password est obligatoire";
        }
        if (count($errors)===0) {
            $user=getUserByLoginAndPassword(trim($_REQUEST["login"]),trim($_REQUEST["password"]));
            if ($user==null) {
                // header("location:".WEBROOT);
                // exit;
                # code...
            }else {
                $isconnected=true;
                if ($user["acteur"]=="rs") {
                    header("Location: index.php?page=produit");
                    exit;
                    # code...
                }else {
                    header("Location: index.php?page=produit");
                    exit;
                }
            }
            # code...
        }
        # code...
        break;
    default:
        # code...
        break;
}
                include_once dirname(__DIR__)."/views/login.html.php";
                # code...
                break;
            default:
                # code...
                break;
        }
         ?>
</body>
</html>