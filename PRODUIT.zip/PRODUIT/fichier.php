<?php
define("BD","../produit.json");
function readJson():array{
    $json=file_get_contents(BD);
    $bd=json_decode($json,true);
    if ($bd!=null){
        return $bd;
    }
    return [];
}
function writeJson(string $key ,array $data):void{
    $bd=readJson();
    $bd[$key][]=$data;
    $json=json_encode($bd,JSON_PRETTY_PRINT);
    file_put_contents(BD,$json);
}
